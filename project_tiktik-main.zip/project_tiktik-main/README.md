# Build and Deploy a Full Stack TikTok Clone Application and Master TypeScript | Full Course
![TikTik](https://i.ibb.co/w7WyFJG/Tik-Tok-Clone-Thumbnail-2.png)

## Introduction
This is a code repository for the corresponding video tutorial.

## Launch your development career with project-based coaching - https://www.jsmastery.pro
